<script>
        // Sample data for friends
        const friendsData = [
            { name: "John Doe", photo: "john.jpg" },
            { name: "Jane Smith", photo: "jane.jpg" },
            { name: "Bob Johnson", photo: "bob.jpg" },
            // Add more friends as needed
        ];

        // Function to create a friend element and add it to the list
        function createFriendElement(friend) {
            const friendElement = document.createElement("div");
            friendElement.classList.add("friend");

            const imgElement = document.createElement("img");
            imgElement.src = friend.photo;

            const nameElement = document.createElement("span");
            nameElement.textContent = friend.name;

            friendElement.appendChild(imgElement);
            friendElement.appendChild(nameElement);

            return friendElement;
        }

        // Function to populate the friends list
        function populateFriendsList() {
            const friendsList = document.getElementById("friends-list");

            friendsData.forEach(friend => {
                const friendElement = createFriendElement(friend);
                friendsList.appendChild(friendElement);
            });
        }

        // Call the function to populate the friends list
        populateFriendsList();
    </script>